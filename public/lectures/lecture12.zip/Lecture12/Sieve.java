import java.util.ArrayList;
import java.util.List;

import acm.program.ConsoleProgram;

public class Sieve extends ConsoleProgram {
  
  private static final int LIMIT = 100000000;
  
	public void run() {
	  long startTime = System.currentTimeMillis();
	  
	  boolean[] crossedOut = new boolean[LIMIT];
	  int sqrtLimit = (int)Math.sqrt(LIMIT);
	  for (int i = 2; i <= sqrtLimit; i++) {
	    if (!crossedOut[i]) {
	      for (int j = i * i; j < LIMIT; j += i) {
	        crossedOut[j] = true;
	      }
	    }
	  }
	  
	  for (int i = LIMIT - 1; i >= 0; i--) {
	    if (!crossedOut[i]) {
	      long endTime = System.currentTimeMillis();
	      println("Largest prime less than " + LIMIT + " is " + i + ".");
	      println("Time to compute in ms: " + (endTime - startTime));
	      return;
	    }
	  }	  
	}
	
}

