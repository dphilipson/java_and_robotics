import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.LightSensor;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import lejos.nxt.SoundSensor;
import lejos.nxt.TouchSensor;
import lejos.util.Delay;

public class SensorDemo {

  private static final int SOUND_THRESHOLD = 75;

  /*
   * Starts the motor if it is stopped, or stops it if it's started.
   */
  private void toggleMotor(NXTRegulatedMotor motor) {
    if (motor.isMoving()) {
      motor.stop();
    } else {
      motor.forward();
    }
  }
  
  private void lightSensorDemo() {
    LightSensor light = new LightSensor(SensorPort.S1);
    while (true) {
      LCD.clear();
      for (int row = 0; row < 8; row++) {

        for (int col = 0; col < 5; col++) {
          int lightIntensity = light.getLightValue();
          LCD.drawInt(lightIntensity, 4 * col, row);
          Delay.msDelay(250);
        }

      }
    }    
  }

  private void soundSensorDemo() {
    SoundSensor sound = new SoundSensor(SensorPort.S1);

    // Uses loud noises to turn on or off the motor.
    while (!Button.ESCAPE.isPressed()) {
      int soundIntensity = sound.readValue();
      LCD.clear();
      LCD.drawInt(soundIntensity, 0, 0);

      if (soundIntensity > SOUND_THRESHOLD) {
        toggleMotor(Motor.A);
        Delay.msDelay(2000);
      }
      Delay.msDelay(250);
    }

    /*
     * I want to print something like:
     * 
     * 3 4 8 50 80 50 40 10 2 0
     */
    while (true) {
      LCD.clear();
      for (int row = 0; row < 8; row++) {

        for (int col = 0; col < 5; col++) {
          int soundIntensity = sound.readValue();
          LCD.drawInt(soundIntensity, 4 * col, row);
          Delay.msDelay(250);
        }

      }
    }
  }

  private void touchSensorDemo() {
    TouchSensor touch = new TouchSensor(SensorPort.S1);
    boolean pressed = false;

    Motor.A.setSpeed(180);

    // Uses clicks on the sensor to toggle the motor.
    while (!Button.ESCAPE.isPressed()) {
      if (touch.isPressed()) {
        pressed = true;
      }
      if (!touch.isPressed() && pressed) {
        toggleMotor(Motor.A);
        pressed = false;
      }
      Delay.msDelay(100);
    }

    // Motor stops spinning and message appears when sensor
    // is pressed.
    Motor.A.forward();
    while (!touch.isPressed()) {
      Delay.msDelay(100);
    }
    Motor.A.stop();
    LCD.drawString("Sensor pressed.", 0, 0);
    Button.waitForPress();
  }

  public static void main(String[] args) {
    SensorDemo demo = new SensorDemo();
    // demo.touchSensorDemo();
    // demo.soundSensorDemo();
    demo.lightSensorDemo();
  }

}
