import lejos.nxt.LCD;
import lejos.nxt.Motor;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.util.Delay;


public class PilotDemo {
  
  private DifferentialPilot pilot;
  
  public void turnLeft() {
    // DifferentialPilot pilot =
    //    new DifferentialPilot(8.5, 9, Motor.A, Motor.B);
    pilot.rotate(90);
  }
  
  public void doStuff() {
    pilot.setTravelSpeed(10); // How fast it moves forward
    pilot.setRotateSpeed(30); // How fast it turns in place,
                              // in degrees per second
    pilot.forward();
    // Basically equivalent to:
    //     Motor.A.forward();
    //     Motor.B.forward();
    Delay.msDelay(2000);
    pilot.stop();
    
    pilot.travel(200);
    
    pilot.rotate(180); // angle in degrees
    pilot.rotate(90); // angles measured counter-clockwise
                      // this is a left turn
    pilot.rotate(-90); // this is a right turn
    
    pilot.rotate(180, true); // returns immediately
    
    pilot.arc(10, 90); // in my length units, and degrees
    
    double angleTurned = pilot.getMovement().getAngleTurned();
    LCD.drawInt((int)angleTurned, 0, 0);
    LCD.drawString("" + angleTurned, 0, 1);
    
    // "The number is " + num
  }

  public static void main(String[] args) {
    
    PilotDemo demo = new PilotDemo();
    
    demo.pilot = new DifferentialPilot(8.5, 9, Motor.A, Motor.B);
    // Arguments are: wheel diameter, track width,
    //     left motor, right motor
    
    demo.doStuff();
    
  }
  
}
