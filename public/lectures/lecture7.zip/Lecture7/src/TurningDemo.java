import lejos.nxt.Button;
import lejos.nxt.Motor;
import lejos.util.Delay;


public class TurningDemo {
  
  public static void main(String[] args) {
    Motor.A.setSpeed(360);
    Motor.B.setSpeed(720);
    Delay.msDelay(1000);
    Motor.A.forward();
    Motor.B.forward();
    Button.waitForPress();
  }

}
