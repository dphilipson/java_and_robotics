import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.Motor;


public class RotationDemo {
  
  public static void main(String[] args) {
    
    Motor.A.setSpeed(720); // in degrees per second
    Motor.A.rotate(1440); // in degrees
    LCD.drawInt(Motor.A.getTachoCount(), 0, 0);
    Button.waitForPress();
    Motor.A.rotateTo(1800);
    LCD.drawInt(Motor.A.getTachoCount(), 0, 1);
    Button.waitForPress();
    Motor.A.rotateTo(-360);
    LCD.drawInt(Motor.A.getTachoCount(), 0, 2);
    Button.waitForPress();
    
    // Results:
    // 1439
    // 1799
    // -359
  }

}
