import lejos.nxt.Button;
import lejos.nxt.Motor;
import lejos.util.Delay;

public class StoppingDemo {

  public static void main(String[] args) {
    // Goal: run for five rotations, but stop in the middle
    // if the user presses a button.
    
    Motor.A.setSpeed(360);
    Motor.A.rotate(1800, true); // returns immediately
    Delay.msDelay(1000);
    while (Motor.A.isMoving()) {
      if (Button.readButtons() > 0) {
        Motor.A.stop();
      }
      Delay.msDelay(200);
    }
  }

}
