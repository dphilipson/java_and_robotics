import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.Motor;
import lejos.util.Delay;


public class TachoDemo {

  public static void main(String[] args) {
    Motor.A.setSpeed(720);
    Motor.A.forward();
    Delay.msDelay(2000);
    // Moving forward at 720 degrees per second for 2 seconds
    LCD.drawInt(Motor.A.getTachoCount(), 0, 0);
    Motor.A.stop();
    LCD.drawInt(Motor.A.getTachoCount(), 0, 1);
    Button.waitForPress();
    
    // Results:
    // 1396
    // 1436
  }
}
