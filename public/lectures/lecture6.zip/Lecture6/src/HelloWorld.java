import lejos.nxt.Button;
import lejos.nxt.LCD;


public class HelloWorld {
  
  public static void main(String[] args) {
    LCD.drawString("Hello, World!", 0, 0);
    Button.waitForPress();
    LCD.drawString("This is the second line!", 0, 1);
    Button.waitForPress();
  }

}
