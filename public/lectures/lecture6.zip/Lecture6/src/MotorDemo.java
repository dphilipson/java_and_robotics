import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.Motor;


public class MotorDemo {

  public static void main(String[] args) {
    Motor.A.setSpeed(720);
    Motor.A.forward();
    Button.waitForPress();
    Motor.A.stop();
    int tachoCount = Motor.A.getTachoCount();
    LCD.drawInt(tachoCount, 0, 0);
    Button.waitForPress();

    
    
//    Motor.A.backward();
//    Button.waitForPress();
    
//    int buttonPressed = Button.waitForPress();
//    if (buttonPressed == Button.ID_ENTER){
//      // do stuff
//    }
  }
}
