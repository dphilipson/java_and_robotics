import java.awt.Color;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;


public class MovingBallsDemo extends GraphicsProgram {
  
  private static final double RADIUS = 3;
  private static final int PAUSE_INTERVAL = 15;
  private static final int NUM_BALLS = 6;
  
  private static RandomGenerator rand = RandomGenerator.getInstance();
  
  public void run() {
    
    Movable[] balls = new Movable[NUM_BALLS];
    
    for (int i = 0; i < balls.length; i++) {
      GOval oval = new GOval(2 * RADIUS, 2 * RADIUS);
      oval.setFillColor(rand.nextColor());
      oval.setFilled(true);
      oval.setLocation(getWidth() / 2 - RADIUS, getHeight() / 2 - RADIUS);
      add(oval);
      double dx = rand.nextDouble(-2, 2);
      double dy = rand.nextDouble(-2, 2);
      if (i % 3 == 0) {
        balls[i] = new MovingBall(oval, dx, dy, this);
      } else if (i % 3 == 1) {
        balls[i] = new BouncingBall(oval, dx, dy, this);
      } else {
        balls[i] = new TeleportingBall(oval, dx, dy, this);
      }
    }
    
    while (true) {
      for (int i = 0; i < balls.length; i++) {
        balls[i].move();
      }
      pause(PAUSE_INTERVAL);
    }
  }
  
  
  
  public static void main(String[] args) {
    new MovingBallsDemo().start(args);
  }

}
