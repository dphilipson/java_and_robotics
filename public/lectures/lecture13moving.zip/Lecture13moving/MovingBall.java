import acm.graphics.GOval;
import acm.program.GraphicsProgram;


public class MovingBall implements Movable {
  
  public GOval ball;
  public double dx;
  public double dy;
  
  private GraphicsProgram parent;
  
  // private static final double WINDOW_WIDTH = 764;
  // private static final double WINDOW_HEIGHT = 551;
  
  public MovingBall(GOval ball, double dx, double dy, GraphicsProgram parent) {
    this.ball = ball;
    this.dx = dx;
    this.dy = dy;
    this.parent = parent;
  }
  
  public void move() {
    ball.move(dx, dy);
  }

}
