import acm.graphics.GOval;
import acm.program.GraphicsProgram;


public class TeleportingBall implements Movable {
  
  public GOval ball;
  public double dx;
  public double dy;
  
  private GraphicsProgram parent;
  
  // private static final double WINDOW_WIDTH = 764;
  // private static final double WINDOW_HEIGHT = 551;
  
  public TeleportingBall(GOval ball, double dx, double dy, GraphicsProgram parent) {
    this.ball = ball;
    this.dx = dx;
    this.dy = dy;
    this.parent = parent;
  }
  
  public void move() {
    ball.move(dx, dy);
    
    if (ball.getX() + ball.getWidth() < 0) {
      // Off left edge
      ball.setLocation(parent.getWidth(), ball.getY());
    } else if (ball.getX() > parent.getWidth()) {
      // Off right edge
      ball.setLocation(-ball.getWidth(), ball.getY());
    }
    
    if (ball.getY() + ball.getHeight() < 0) {
      // Off top edge
      ball.setLocation(ball.getX(), parent.getHeight());
    } else if (ball.getY() > parent.getWidth()) {
      // Off bottom edge
      ball.setLocation(-ball.getHeight(), ball.getY());
    }
    
  }

}
