import acm.graphics.GOval;
import acm.program.GraphicsProgram;


public class BouncingBall implements Movable {
  
  public GOval ball;
  public double dx;
  public double dy;
  
  private GraphicsProgram parent;
  
  // private static final double WINDOW_WIDTH = 764;
  // private static final double WINDOW_HEIGHT = 551;
  
  public BouncingBall(GOval ball, double dx, double dy, GraphicsProgram parent) {
    this.ball = ball;
    this.dx = dx;
    this.dy = dy;
    this.parent = parent;
  }
  
  public void move() {
    ball.move(dx, dy);
    if (ball.getX() + ball.getWidth() > parent.getWidth() ||
        ball.getX() < 0) {
      dx = -dx;
    }
    
    if (ball.getY() + ball.getHeight() > parent.getHeight() ||
        ball.getY() < 0) {
      dy = -dy;
    }
  }

}
