
public class Fraction {
  
  private int numerator;
  private int denominator;
  
  public Fraction(int num, int denom) {
    numerator = num;
    denominator = denom;
    reduce();
  }
  
  public Fraction(int num) {
    numerator = num;
    denominator = 1;
  }
  
  public int getNumerator() {
    return numerator;
  }
  
  public int getDenominator() {
    return denominator;
  }
  
  public String toString() {
    if (denominator == 1) {
      return "" + numerator;
    }
    return "" + numerator + "/" + denominator;
  }
  
  public Fraction plus(Fraction other) {
    // a/b + c/d = (ad + bc) / (bd)
    int newNumerator = numerator * other.denominator
        + other.numerator * denominator;
    int newDenominator = denominator * other.denominator;
    
    return new Fraction(newNumerator, newDenominator);
  }
  
  public Fraction minus(Fraction other) {
    // a/b + c/d = (ad - bc) / (bd)
    int newNumerator = numerator * other.denominator
        - other.numerator * denominator;
    int newDenominator = denominator * other.denominator;
    
    return new Fraction(newNumerator, newDenominator);
  }
  
  public Fraction times(Fraction other) {
    // a/b * c/d = (ac) / (bd)
    int newNumerator = numerator * other.numerator;
    int newDenominator = denominator * other.denominator;
    
    return new Fraction(newNumerator, newDenominator);
  }
  
  public Fraction dividedBy(Fraction other) {
    // (a/b) / (c/d) = (ad) / (bc)
    int newNumerator = numerator * other.denominator;
    int newDenominator = denominator * other.numerator;
    
    return new Fraction(newNumerator, newDenominator);
  }
  
  // Euclidian algorithm
  // named after Euclid
  private int gcd(int a, int b) {
    if (a == 0) {
      return b;
    }
    if (b == 0) {
      return a;
    }
    if (a < 0) {
      a = -a;
    }
    if (b < 0) {
      b = -b;
    }
    while (a != b) {
      if (a < b) {
        b -= a; // shorthand for b = b - a
      } else {
        a -= b;
      }
    }
    return a;
  }
  
  /*
   * Another way to write gcd.
   */
  private int alternateGcd(int a, int b) {
    if (a == 0) {
      return b;
    }
    return alternateGcd(b % a, a);
  }
  
  /*
   * Puts the fraction in lowest terms.
   */
  private void reduce() {
    int gcd = gcd(numerator, denominator);
    
    // shorthand for numerator = numerator / gcd
    numerator /= gcd;
    denominator /= gcd;
    
    if (denominator < 0) {
      numerator = -numerator;
      denominator = -denominator;
    }
  }
  
  // to get a double from a string:
  // Double.parseDouble("3.14159");
  
  public double toDouble() {
    return (double)numerator / denominator;
    
  }

}
