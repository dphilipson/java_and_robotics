import acm.program.ConsoleProgram;


public class FractionDemo extends ConsoleProgram {
  
  public void run() {
    Fraction f1 = new Fraction(1, 3); // Represents 1/3
    println("The fraction is " + f1); 
    // Should print "The fraction is 1/3"
    
    Fraction f2 = new Fraction(1, 2);
    println("Second fraction is " + f2);
    
    println("The sum is " + f1.plus(f2));
    println("The difference is " + f1.minus(f2));
    println("The product is " + f1.times(f2));
    println("First divided by second is " + f1.dividedBy(f2));
    
    println();
    println("**********");
    println();
    
    f1 = new Fraction(1, 3);
    f2 = new Fraction(1, 6);
    println("" + f1 + " + " + f2 + " is " + f1.plus(f2));
    
    f1 = new Fraction(7);
    f2 = new Fraction(-2);
    println("" + f1 + " divided by " + f2 + " is " + f1.dividedBy(f2));
    
    println("The numerator of " + f1 + " is " + f1.getNumerator());
    println("The denominator of " + f2 + " is " + f2.getDenominator());
    
    f1 = new Fraction(1, 7);
    println("" + f1 + " as a double is " + f1.toDouble());
    
  }
}
