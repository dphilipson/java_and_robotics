
public class Pair {
  
  public int first;
  public int second;
  
  private int counter = 0;
  
  // This is a constructor
  public Pair(int first, int second) {
    this.first = first;
    this.second = second;
  }
  
  public Pair() {
    
  }
  
  // Returns the number of times sum() has been called
  public int numberOfSumCalls() {
    return counter;
  }
  
  public int sum() {
    counter++;
    return first + second;
    // Above line equivalent to: 
    //   return this.first + this.second;
  }

}
