import java.awt.Color;

import acm.graphics.GOval;
import acm.io.IODialog;
import acm.program.GraphicsProgram;

/*
 * File: BlankClass.java
 * ---------------------
 * This class is a blank one that you can change at will. Remember, if you change
 * the class name, you'll need to change the filename so that it matches.
 * Then you can extend GraphicsProgram, ConsoleProgram, or DialogProgram as you like.
 */

public class DialogDemo extends GraphicsProgram {
  
  public void run() {
    IODialog dialog = new IODialog();
    dialog.println("Hello, World!");
    double radius = dialog.readDouble("Enter radius:");
    GOval circle = getCenteredCircle(radius);
    add(circle);
    radius = dialog.readDouble("Enter another radius:");
    circle.setSize(2 * radius, 2 * radius);
    dialog.println("Circle is about to disappear!");
    remove(circle);
  }
  
  private GOval getCenteredCircle(double radius) {
    GOval circle = new GOval(2 * radius, 2 * radius);
    circle.setLocation(getWidth() / 2 - radius, getHeight() / 2 - radius);
    circle.setFillColor(Color.BLUE);
    circle.setFilled(true);
    return circle;
  }

}
