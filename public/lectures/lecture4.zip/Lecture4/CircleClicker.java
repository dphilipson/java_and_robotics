import java.awt.event.MouseEvent;

import acm.graphics.GObject;
import acm.graphics.GOval;
import acm.io.IODialog;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;


public class CircleClicker extends GraphicsProgram {

  private static final double MIN_RADIUS = 5.0;
  private static final double MAX_RADIUS = 50.0;
  
  private static RandomGenerator rgen = RandomGenerator.getInstance();
  private int numCircles;
  
  public void run() {
    IODialog dialog = new IODialog();
    numCircles = dialog.readInt("Enter number of circles: ");
    
    for (int i = 0; i < numCircles; i++) {
      drawRandomCircle();
    }
    
    addMouseListeners();
  }
  
  private void drawRandomCircle() {
    double radius = rgen.nextDouble(MIN_RADIUS, MAX_RADIUS);
    GOval circle = new GOval(2 * radius, 2 * radius);
    circle.setLocation(rgen.nextDouble(0, getWidth() - 2 * radius),
        rgen.nextDouble(0, getHeight() - 2 * radius));
    circle.setFillColor(rgen.nextColor());
    circle.setFilled(true);
    add(circle);
  }
  
  public void mousePressed(MouseEvent e) {
    GObject clicked = getElementAt(e.getX(), e.getY());
    if (clicked != null) {
      remove(clicked);
      numCircles--;
      if (numCircles == 0) {
        (new IODialog()).println("You win!");
      }
    }
  }
  
}
