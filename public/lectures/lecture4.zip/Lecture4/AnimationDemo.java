import java.awt.Color;

import acm.graphics.GRect;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class AnimationDemo extends GraphicsProgram {

  private static final double WIDTH = 40;
  private static final double HEIGHT = 40;
  private static final double PAUSE_TIME = 15;
  private static final double INITIAL_DX = 2;
  private static final double INITIAL_DY = 2;
  
  public void run() {
    
    double dx = INITIAL_DX;
    double dy = INITIAL_DY;
    GRect rect = new GRect(WIDTH, HEIGHT);
    rect.setFillColor(Color.BLUE);
    rect.setFilled(true);
    add(rect);
    while (true) {
      pause(PAUSE_TIME);
      rect.move(dx, dy);
      if (rect.getX() + WIDTH > getWidth() || rect.getX() < 0) {
        dx = -dx;
        rect.setFillColor(RandomGenerator.getInstance().nextColor());
      }
      if (rect.getY() + HEIGHT > getHeight() || rect.getY() < 0) {
        dy = -dy;
        rect.setFillColor(RandomGenerator.getInstance().nextColor());
      }
    }
  }
  
}
