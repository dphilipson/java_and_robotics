import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.graphics.GObject;
import acm.graphics.GOval;
import acm.io.IODialog;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class MouseDemo extends GraphicsProgram {

  private static final double RADIUS = 40;
  private static final double DX = 10;
  private static final double SMALL_RADIUS = 3;
  
  private boolean drawCircles = false;
  
  public void run() {
    addMouseListeners();
    
    IODialog dialog = new IODialog();
    dialog.println("Click the mouse!");
    
    GOval circle = new GOval(2 * RADIUS, 2 * RADIUS);
    circle.setLocation(getWidth() / 2 - RADIUS, getHeight() / 2 - RADIUS);
    circle.setFillColor(Color.BLUE);
    circle.setFilled(true);
    add(circle);
    
    GOval circle2 = new GOval(2 * RADIUS, 2 * RADIUS);
    circle2.setLocation(getWidth() / 2 - RADIUS * 4, getHeight() / 2 - RADIUS);
    circle2.setFillColor(Color.GREEN);
    circle2.setFilled(true);
    add(circle2);
  }
  
  public void mousePressed(MouseEvent e) {
    
    //IODialog dialog = new IODialog();
    double x = e.getX();
    double y = e.getY();
    
    GObject clicked = getElementAt(x, y);
    if (clicked != null) {
      clicked.move(DX, 0);
    } else {
      setBackground(RandomGenerator.getInstance().nextColor());
    }
    
    if (drawCircles) {
      drawCircles = false;
    } else {
      drawCircles = true;
    }
    // dialog.println("You clicked at (" + x + ", " + y + ").");
    
  }
  
  public void mouseMoved(MouseEvent e) {
    if (drawCircles) {
      double x = e.getX();
      double y = e.getY();
      

      GOval circle = new GOval(2 * SMALL_RADIUS, 2 * SMALL_RADIUS);
      circle.setLocation(x - SMALL_RADIUS, y - SMALL_RADIUS);
      add(circle);
    }
  }
}
