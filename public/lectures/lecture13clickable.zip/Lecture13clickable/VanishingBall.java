import acm.graphics.GOval;


public class VanishingBall extends GOval implements Clickable {
  
  public VanishingBall(double x, double y, double width, double height) {
    super(x, y, width, height);
  }
  
  public VanishingBall(double width, double height) {
    super(width, height);
  }
  
  public void respondToClick() {
    setVisible(false);
  }
  

}
