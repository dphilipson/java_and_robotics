/*
 * File: BlankClass.java
 * ---------------------
 * This class is a blank one that you can change at will. Remember, if you change
 * the class name, you'll need to change the filename so that it matches.
 * Then you can extend GraphicsProgram, ConsoleProgram, or DialogProgram as you like.
 */

import java.awt.event.MouseEvent;

import acm.graphics.GLabel;
import acm.graphics.GObject;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class CircleClicker extends GraphicsProgram {
//	public void run() {
//		
//	  GOval circle = new VanishingBall(300, 200, 50, 50);
//	  circle.setColor(Color.BLUE);
//	  circle.setFilled(true);
//	  add(circle);
//	  
//	  GOval colorChanger = new ColorChangingBall(400, 500, 40, 40);
//	  colorChanger.setColor(Color.BLACK);
//	  colorChanger.setFilled(true);
//	  add(colorChanger);
//	  
//	  addMouseListeners();
//	}
  
  private static final int NUM_BALLS = 100;
  private static final double RADIUS = 20;
  private static final double MAX_SPEED = 2;
  private static final int PAUSE_TIME = 15;
  
  private int ballsClicked = 0;
  
  public void run() {
    Movable[] balls = new Movable[NUM_BALLS];
    RandomGenerator rand = RandomGenerator.getInstance();
    
    for (int i = 0; i < NUM_BALLS; i++) {
      double x = getWidth() / 2 - RADIUS;
      double y = getHeight() / 2 - RADIUS;
      double dx = rand.nextDouble(-MAX_SPEED, MAX_SPEED);
      double dy = rand.nextDouble(-MAX_SPEED, MAX_SPEED);
      MovingVanishingBall b = new MovingVanishingBall(x, y, 2 * RADIUS,
          2 * RADIUS, dx, dy);
      b.setColor(rand.nextColor());
      b.setFilled(true);
      add(b);
      balls[i] = b;
    }
    
    GLabel label = new GLabel("");
    label.setLocation(10, getHeight() - 10);
    add(label);
    
    addMouseListeners();
    
    while (true) {
      for (int i = 0; i < balls.length; i++) {
        balls[i].move();
      }
      label.setLabel("Balls clicked: " + ballsClicked);
      pause(PAUSE_TIME);
    }
  }
	
	public void mousePressed(MouseEvent e) {
	  GObject o = getElementAt(e.getX(), e.getY());
	  if (o != null) {
	    if (o instanceof Clickable) {
	      Clickable clicked = (Clickable) o;
	      clicked.respondToClick();
	      ballsClicked++;
	    }
	  }
	}
}

