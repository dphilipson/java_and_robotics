
public interface Movable {

  public void move();
  
}
