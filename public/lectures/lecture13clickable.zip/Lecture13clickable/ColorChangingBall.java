import acm.graphics.GOval;
import acm.util.RandomGenerator;


public class ColorChangingBall extends GOval implements Clickable {
  
  public ColorChangingBall(double x, double y, double width, double height) {
    super(x, y, width, height);
  }
  
  public ColorChangingBall(double width, double height) {
    super(width, height);
  }
  
  public void respondToClick() {
    setColor(RandomGenerator.getInstance().nextColor());
  }

}
