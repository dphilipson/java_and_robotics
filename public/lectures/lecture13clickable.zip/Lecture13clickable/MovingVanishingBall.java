import acm.graphics.GOval;

public class MovingVanishingBall extends GOval implements Clickable, Movable {

  double dx;
  double dy;

  MovingVanishingBall(double x, double y, double width, double height,
      double dx, double dy) {

    super(x, y, width, height);
    this.dx = dx;
    this.dy = dy;
    
  }
  
  public void respondToClick() {
    setVisible(false);
  }
  
  public void move() {
    move(dx, dy);
  }

}