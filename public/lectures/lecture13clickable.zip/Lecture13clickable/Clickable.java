
public interface Clickable {

  public void respondToClick();
  
}
