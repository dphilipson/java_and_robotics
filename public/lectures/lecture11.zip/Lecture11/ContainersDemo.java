import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import acm.program.ConsoleProgram;

public class ContainersDemo extends ConsoleProgram {

  public void run() {
    wordFrequencyDemo();
  }
  
  private void wordFrequencyDemo() {
    String input = readLine("Enter file name: ");
    ArrayList<String> words = getLinesFromFile(input);
    if (words == null) {
      println("File not found!");
      return;
    }
    
    HashMap<String, Integer> counts = new HashMap<String, Integer>();
    
    for (String word : words) {
      if (!counts.containsKey(word)) {
        counts.put(word, 1);
      } else {
        int oldValue = counts.get(word);
        counts.put(word, oldValue + 1);
      }
    }
    
    for (String word : counts.keySet()) {
      println(word + ": " + counts.get(word));
    }
    
  }
  
  private void dictionaryDemo() {
    HashMap<String, String> dict = new HashMap<String, String>();
    dict.put("left", "Opposite of right");
    dict.put("above", "On top of");
    dict.put("red", "A reddish color");
    
    while (true) {
      String input = readLine("Enter word: ");
      if (input.equals("")) {
        break;
      }
      String output = dict.get(input);
      if (output == null) {
        println("Word not in dictionary!");
      } else {
        println(output);
      }
    }
    
    for (String key : dict.keySet()) {
      println("Key: " + key + ", Value: " + dict.get(key));
    }
  }
  
  private void uniqueWordsDemo() {
    int numTotalWords = getLinesFromFile("gatsby.txt").size();
    HashSet<String> uniqueWords = getUniqueWords("gatsby.txt"); 
    int numUniqueWords = uniqueWords.size();
    
    println("Total words: " + numTotalWords);
    println("Unique words: " + numUniqueWords);
    
    numTotalWords = getLinesFromFile("literature.txt").size();
    uniqueWords = getUniqueWords("literature.txt"); 
    numUniqueWords = uniqueWords.size();
    
    println("Total words: " + numTotalWords);
    println("Unique words: " + numUniqueWords);

  }
  
  private HashSet<String> getUniqueWords(String filename) {
    Collection<String> list = getLinesFromFile(filename);
    
    HashSet<String> uniqueWords = new HashSet<String>();
    for (String word : list) {
      uniqueWords.add(word);
    }
    return uniqueWords;
  }
  
  private void noVowelsDemo() {
    ArrayList<String> words = getLinesFromFile("scrabble.txt");
    for (String word : words) {
      if (hasNoVowels(word)) {
        println(word);
      }
    }
    
  }
  
  private boolean hasNoVowels(String word) {
    for (int i = 0; i < word.length(); i++) {
      if (isVowel(word.charAt(i))) {
        return false;
      }
    }
    return true;
  }
  
  private void vowelCountDemo() {
    ArrayList<String> words = getLinesFromFile("scrabble.txt");
    int count = 0;
    for (String word : words) {
      if (hasMoreVowelsThanConsonants(word)) {
        count++;
      }
    }
    double percentage = ((double)count) / words.size() * 100;
    println("Percentage of words with more vowels than consonants: "
        + percentage);
  }

  private boolean hasMoreVowelsThanConsonants(String word) {
    int count = 0;
    for (int i = 0; i < word.length(); i++) {
      if (isVowel(word.charAt(i))) {
        count++;
      }
    }
    return 2 * count > word.length();
    // or: return count > word.length() / 2;
  }

  private boolean isVowel(char c) {
    c = Character.toUpperCase(c);
    return c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U';
  }

  private ArrayList<String> getLinesFromFile(String filename) {
    ArrayList<String> lines = new ArrayList<String>();
    try {
      BufferedReader rd = new BufferedReader(new FileReader(filename));
      while (true) {
        String line = rd.readLine();
        if (line == null) {
          break;
        }
        lines.add(line);
      }
    } catch (IOException e) {
      return null;
    }
    return lines;
  }

  private void exceptionDemo() {
    try {
      int i = 2 / 0;
    } catch (ArithmeticException e) {
      println("Divided by zero!");
    }
  }

  private void fileReadDemo() {
    try {
      BufferedReader rd = new BufferedReader(new FileReader("common.txt"));
      while (true) {
        String line = rd.readLine();
        if (line == null) {
          break;
        }
        println(line);
      }
    } catch (IOException e) {
      println("File not found!");
    }
  }

  private void intEntryDemo() {
    ArrayList<Integer> nums = new ArrayList<Integer>();

    while (true) {
      int input = readInt("Enter int (or enter -1 to finish): ");
      if (input == -1) {
        break;
      }
      nums.add(input);
    }

    for (Integer n : nums) {
      println("" + n);
    }
  }

  private void stringEntryDemo() {

    ArrayList<String> words = new ArrayList<String>();

    while (true) {
      String input = readLine("Enter a word (or leave blank to finish): ");
      if (input.equals("")) {
        break;
      }
      words.add(input);
    }

    int length = words.size();
    for (int i = 0; i < length; i++) {
      println(words.get(i));
      // print(words.get(i) would not have endlines.
    }

    for (String s : words) {
      println(s);
    }

    String[] arr = { "This", "is", "an", "array" };
    for (String s : arr) {
      println(s);
    }

  }

}
