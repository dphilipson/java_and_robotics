import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import acm.program.ConsoleProgram;

public class DocumentTokenizer extends ConsoleProgram {

  public void run() {
    String inputFile = readLine("Enter input filename: ");
    String outputFile = readLine("Enter output filename: ");

    tokenizeFile(inputFile, outputFile);
    println("Done.");
  }

  private void tokenizeFile(String inputFile, String outputFile) {
    try {
      BufferedReader in = new BufferedReader(new FileReader(inputFile));
      BufferedWriter out = new BufferedWriter(new FileWriter(outputFile));

      String line = in.readLine();
      while (line != null) {
        Scanner scan = new Scanner(line).useDelimiter("[^a-zA-Z']");
        while (scan.hasNext()) {
          String word = scan.next().toUpperCase();
          if (!word.equals("")) {
            out.write(word + "\n");
          }
        }
        line = in.readLine();
      }
      in.close();
      out.close();
    } catch (IOException ex) {
      ex.printStackTrace();
      System.exit(-1);
    }
  }
}
