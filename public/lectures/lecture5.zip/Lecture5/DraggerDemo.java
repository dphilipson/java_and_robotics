import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.graphics.GRect;
import acm.program.GraphicsProgram;

public class DraggerDemo extends GraphicsProgram {

  private static final double SIDE_LENGTH = 200;

  private GRect square;
  private boolean currentlyDragging = false;
  private double oldX;
  private double oldY;

  public void run() {
    square = new GRect(SIDE_LENGTH, SIDE_LENGTH);
    square.setFillColor(Color.MAGENTA);
    square.setFilled(true);
    add(square);

    addMouseListeners();
  }

  public void mousePressed(MouseEvent e) {
    double x = e.getX();
    double y = e.getY();
    
    if (getElementAt(x, y) == square) {
      currentlyDragging = true;
      oldX = x;
      oldY = y;
    }
  }

  public void mouseReleased(MouseEvent e) {
    currentlyDragging = false;
  }

  public void mouseDragged(MouseEvent e) {
    if (currentlyDragging) {
      double x = e.getX();
      double y = e.getY();

      square.move(x - oldX, y - oldY);
      oldX = x;
      oldY = y;
      //square.setLocation(x - SIDE_LENGTH / 2, y - SIDE_LENGTH / 2);
    }
  }
  
}