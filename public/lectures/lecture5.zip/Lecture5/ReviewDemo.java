import acm.program.ConsoleProgram;


public class ReviewDemo extends ConsoleProgram {
  public void run() {
    for (int i = 0; i < 7; i++) {
      println("Hello, World!");
    }
    
    int j = 0;
    j = 1;
    while (j < 7) {
      println("Hello, While-loop!");
      j += 2;
    }
    
    int a = 2;
    int b = 3;
    
    println("a and b are (" + a + ", " + b + ").");
    
    int dummy = a;
    a = b;
    b = dummy;
    
    println("a and b are (" + a + ", " + b + ").");
    
    // int, long, double, boolean, char
    
    String s = "Hello, String!";
    println(s);
    println("Length is " + s.length());
    println("First character is " + s.charAt(0));
    
    long[] arr = new long[4];
    
    arr[0] = 1234512312312L;
    for (int i = 0; i < arr.length; i++) {
      println("Array element at index " + i + " is " + arr[i]);
    }
    
    int input = readInt("Enter an int: ");
    println("" + input + "! is " + factorial(input));
    
  }
  
  // 3! is 3 * 2 * 1 is 6
  // ABC, ACB, BAC, BCA, CAB, CBA
  
  // factorial(0) = 1
  // factorial(n) = n * factorial(n-1) for n > 0
  
  private long factorial(int n) {
    if (n == 0) {
      return 1;
    } else {
      return n * factorial(n - 1);
    }
  }
  
//  private long factorial(int n) {
//    long result = 1;
//    for (int i = 1; i <= n; i++) {
//      result *= i;
//    }
//    return result;
//  }
}
