import java.awt.event.KeyEvent;

import acm.graphics.GImage;
import acm.program.GraphicsProgram;


public class KeyboardDemo extends GraphicsProgram {
  
  private static final double SIDE_LENGTH = 40;
  private static final double INCREMENT = 40;
  
  private GImage image;
  
  public void run() {
    image = new GImage("wheatley.jpg");
    image.setSize(SIDE_LENGTH, SIDE_LENGTH);
    add(image);
    
    addKeyListeners();
  }
  
  public void keyTyped(KeyEvent e) {
//    char key = e.getKeyChar();
//    
//    if (key == 'w') {
//      square.move(0, -INCREMENT);
//    } else if (key == 'a') {
//      square.move(-INCREMENT, 0);
//    } else if (key == 's') {
//      square.move(0, INCREMENT);
//    } else if (key == 'd') {
//      square.move(INCREMENT, 0);
//    }
    
    // IODialog dialog = new IODialog();
    // dialog.println("Key pressed was " + e.getKeyChar());
  }
  
  public void keyPressed(KeyEvent e) {
    int keyCode = e.getKeyCode();
    
    if (keyCode == KeyEvent.VK_LEFT) {
      image.move(-INCREMENT, 0);
    } else if (keyCode == KeyEvent.VK_UP) {
      image.move(0, -INCREMENT);
    } else if (keyCode == KeyEvent.VK_RIGHT) {
      image.move(INCREMENT, 0);
    } else if (keyCode == KeyEvent.VK_DOWN){
      image.move(0, INCREMENT);
    }
  }

}
