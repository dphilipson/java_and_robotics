import lejos.nxt.Button;
import lejos.nxt.Motor;
import lejos.nxt.SensorPort;
import lejos.nxt.UltrasonicSensor;
import lejos.util.Delay;


public class SearchRobot {
  
  private static final int SCAN_INTERVAL = 50;
  private static final int GEAR_SIZE_RATIO = 3;
  private static final int SCAN_SPEED = 90 * GEAR_SIZE_RATIO;
  private static final int FULL_SPEED = 270 * GEAR_SIZE_RATIO;
      
  private int findAngleOfClosestObject() {
    UltrasonicSensor sonic = new UltrasonicSensor(SensorPort.S1);
    int bestAngle = 0;
    int bestDistance = 255;
    
    Motor.A.setSpeed(FULL_SPEED);
    Motor.A.rotateTo(0);
    
    Motor.A.setSpeed(SCAN_SPEED);
    Motor.A.rotate(180 * GEAR_SIZE_RATIO, true); // true for immediate return
    while (Motor.A.isMoving()) {
      int reading = sonic.getDistance();
      if (reading < bestDistance) {
        bestDistance = reading;
        bestAngle = Motor.A.getTachoCount();
      }
      Delay.msDelay(SCAN_INTERVAL);
    }
    return bestAngle;
  }
  
  public void pointToClosestObject() {
    int bestAngle = findAngleOfClosestObject();
    Motor.A.setSpeed(FULL_SPEED);
    Motor.A.rotateTo(bestAngle);
  }
  
  public static void main(String[] args) {
    SearchRobot robot = new SearchRobot();
    while (true) {
      robot.pointToClosestObject();
      Button.waitForPress();
    }
  }
}
