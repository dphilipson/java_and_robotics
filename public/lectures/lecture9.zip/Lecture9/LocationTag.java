
public class LocationTag {
  
  public String firstName;
  public String lastName;
  public String status;
  public double x;
  public double y;
  
  public LocationTag(String firstNameArg, String lastNameArg,
      String statusArg, double xArg, double yArg) {
    firstName = firstNameArg;
    lastName = lastNameArg;
    status = statusArg;
    x = xArg;
    y = yArg;
  }
  
  public LocationTag() {
    // This constructor does nothing.
  }

  public String toString() {
    // Returns something like:
    // James Bond posted "Shaken, not stirred" at location (2, 3).
    return firstName + " " + lastName + " posted \""
        + status + "\" at location (" + x + ", " + y + ").";
  }
  
  public double getDistanceTo(LocationTag otherTag) {
    double dx = otherTag.x - x;
    double dy = otherTag.y - y;
    return Math.sqrt(dx * dx + dy * dy);
  }
}
