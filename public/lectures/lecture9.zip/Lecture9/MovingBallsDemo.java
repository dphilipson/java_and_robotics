import java.awt.Color;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;


public class MovingBallsDemo extends GraphicsProgram {
  
  private static final double RADIUS = 3;
  private static final int PAUSE_INTERVAL = 15;
  private static final int NUM_BALLS = 1000;
  
  private static RandomGenerator rand = RandomGenerator.getInstance();
  
  public void run() {
    MovingBall[] balls = new MovingBall[NUM_BALLS];
    for (int i = 0; i < balls.length; i++) {
      GOval oval = new GOval(2 * RADIUS, 2 * RADIUS);
      oval.setFillColor(rand.nextColor());
      oval.setFilled(true);
      oval.setLocation(getWidth() / 2 - RADIUS, getHeight() / 2 - RADIUS);
      add(oval);
      double dx = rand.nextDouble(-2, 2);
      double dy = rand.nextDouble(-2, 2);
      balls[i] = new MovingBall(oval, dx, dy, this);
    }
    
    while (true) {
      for (int i = 0; i < balls.length; i++) {
        balls[i].move();
      }
      pause(PAUSE_INTERVAL);
    }
  }
  
  
  private void moveTwoBalls() {
    GOval oval = new GOval(2 * RADIUS, 2 * RADIUS);
    oval.setFillColor(Color.BLUE);
    oval.setFilled(true);
    add(oval);
    MovingBall mover = new MovingBall(oval, 2, 3, this);
    
    GOval oval2 = new GOval(2 * RADIUS, 2 * RADIUS);
    oval2.setFillColor(Color.RED);
    oval2.setFilled(true);
    add(oval2);
    MovingBall mover2 = new MovingBall(oval2, 3, 2, this);
    
    while (true) {
      //oval.move(dx, dy);
      //oval2.move(dx2, dy2);
      
      // mover.ball.move(mover.dx, mover.dy);
      // mover2.ball.move(mover2.dx, mover2.dy);
      
      mover.move();
      mover2.move();
      
      pause(PAUSE_INTERVAL);
    }
  }

}
