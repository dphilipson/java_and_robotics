import acm.program.ConsoleProgram;

public class LocationTagDemo extends ConsoleProgram {

  public void run() {
    String firstName = readLine("Enter first name: ");
    String lastName = readLine("Enter last name: ");
    String status = readLine("Enter status: ");
    double x = readDouble("Enter x-coordinate: ");
    double y = readDouble("Enter y-coordinate: ");

    // LocationTag tag = new LocationTag();
    // tag.firstName = firstName;
    // tag.lastName = lastName;
    // tag.status = status;
    // tag.x = x;
    // tag.y = y;
    LocationTag tag = new LocationTag(firstName, lastName, status, x, y);

    println(tag.toString());

    LocationTag tag2 = new LocationTag();
    tag2.firstName = readLine("Enter first name: ");
    tag2.lastName = readLine("Enter last name: ");
    tag2.status = readLine("Enter status: ");
    tag2.x = readDouble("Enter x-coordinate: ");
    tag2.y = readDouble("Enter y-coordinate: ");

    println(tag2.toString());
    println("The distance between the two tags is " + tag.getDistanceTo(tag2)
        + ".");
  }

}
