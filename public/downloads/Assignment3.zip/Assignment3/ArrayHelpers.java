import acm.program.ConsoleProgram;

public class ArrayHelpers extends ConsoleProgram {


  private int findInArray(String needle, String[] haystack) {

    // Your code goes here
    return 0; // You should change this line when you write your code.
  }
  
  
  private int[] rangeArray(int limit) {

    // Your code goes here
    return null; // You should change this line when you write your code.

  }
  
  
  private void sortArray(int[] arr) {
    
    // Your code for the challenge problem goes here
    
  }

  
  /*
   * Runs a series of tests to check the above methods 
   */
  public void run() {
    String[] arr1 = { "Hello", "World", "!" };
    int result1 = findInArray("Hello", arr1);
    println("findInArray(\"Hello\", " + stringArrayToString(arr1)
        + ") returned " + result1 + ", should return 0.");
    println();

    String[] arr2 = { "green", "blue" };
    int result2 = findInArray("blue", arr2);
    println("findInArray(\"blue\", " + stringArrayToString(arr2)
        + ") returned " + result2 + ", should return 1.");
    println();

    String[] arr3 = { "green", "blue" };
    int result3 = findInArray("red", arr3);
    println("findInArray(\"red\", " + stringArrayToString(arr3)
        + ") returned " + result3 + ", should return 0.");
    println();

    println("****************************************");

    int[] arr4 = rangeArray(4);
    println("rangeArray(4) returned " + intArrayToString(arr4)
        + ", should return {1, 2, 3, 4}.");
    println();
    
    int[] arr5 = rangeArray(6);
    println("rangeArray(4) returned " + intArrayToString(arr5)
        + ", should return {1, 2, 3, 4, 5, 6}.");
    println();
  }

  /*
   * Given an array of ints, returns a String representing the array in readable
   * form. Warning: may be slow for large arrays.
   */
  private static String intArrayToString(int[] arr) {
    if (arr == null) {
      return "(null)";
    }
    String result = "{";
    for (int i = 0; i < arr.length; i++) {
      result += arr[i];
      if (i < arr.length - 1) {
        result += ", ";
      }
    }
    result += "}";
    return result;
  }

  /*
   * The same as the last method, except operating on arrays of Strings instead
   * of ints.
   */
  private String stringArrayToString(String[] arr) {
    if (arr == null) {
      return "(null)";
    }
    String result = "{";
    for (int i = 0; i < arr.length; i++) {
      result += arr[i];
      if (i < arr.length - 1) {
        result += ", ";
      }
    }
    result += "}";
    return result;
  }
}
