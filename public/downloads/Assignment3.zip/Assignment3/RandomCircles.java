/*
 * File: BlankClass.java
 * ---------------------
 * This class is a blank one that you can change at will. Remember, if you change
 * the class name, you'll need to change the filename so that it matches.
 * Then you can extend GraphicsProgram, ConsoleProgram, or DialogProgram as you like.
 */

import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class RandomCircles extends GraphicsProgram {

  // Number of circles
  private static final int NUM_CIRCLES = 10;
  
  // Minimum radius
  private static final double MIN_RADIUS = 5;
  
  // Maximum radius
  private static final double MAX_RADIUS = 50;
  

  public void run() {
    // Your code goes here

    // To get a random color, you should write
    //
    //    rand.nextColor();
    //
    
    // To get a random double in the range min to max, you should write
    //
    //    rand.nextDouble(min, max)
    //
  }

  
  // Used for randomness
  private RandomGenerator rand = RandomGenerator.getInstance();
}
