import stanford.karel.*;

public class ExplorerKarel extends SuperKarel {

  // You fill in this part
  
}
