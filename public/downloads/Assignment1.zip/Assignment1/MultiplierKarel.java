import stanford.karel.*;

public class MultiplierKarel extends SuperKarel {
  
  // You fill in this part
  
}
