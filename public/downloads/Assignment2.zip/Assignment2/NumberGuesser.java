import acm.program.ConsoleProgram;


public class NumberGuesser extends ConsoleProgram {

  // Your code goes here
  
}
