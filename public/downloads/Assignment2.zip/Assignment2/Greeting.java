import acm.program.ConsoleProgram;


public class Greeting extends ConsoleProgram {

  // Your code goes here
  
}
