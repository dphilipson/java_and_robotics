import acm.program.ConsoleProgram;


public class VarianceCalculator extends ConsoleProgram {

  // Your code goes here
  
}
