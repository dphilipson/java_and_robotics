import acm.program.ConsoleProgram;


public class AlphabeticalWords extends ConsoleProgram {

}
