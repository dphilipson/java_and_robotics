import acm.program.ConsoleProgram;


public class ClosestNumber extends ConsoleProgram {

}
