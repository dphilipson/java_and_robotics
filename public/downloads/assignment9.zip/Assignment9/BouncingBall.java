import acm.graphics.GOval;


public class BouncingBall {
  
  // TODO: Any instance variables and constants should go here.
  
  public BouncingBall(GOval ball, double dx, double dy) {
    // TODO: Fill in the constructor here.
  }
  
  public void move() {
    // TODO: Fill in the move() method here.
  }

}
