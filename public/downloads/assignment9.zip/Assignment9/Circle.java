public class Circle {

  // TODO: Any instance variables and constants should go here.

  public Circle(double radius) {
    // TODO: Your code here
  }

  public double getRadius() {
    // TODO: Your code here. You should replace the return statement when you
    // write your code.

    return 0;
  }

  public double getCircumference() {
    // TODO: Your code here. You should replace the return statement when you
    // write your code.

    return 0;
  }

  public double getArea() {
    // TODO: Your code here. You should replace the return statement when you
    // write your code.

    return 0;
  }

  public boolean equals(Circle other) {
    // TODO: Your code here. You should replace the return statement when you
    // write your code.
    
    return false;
  }

}
