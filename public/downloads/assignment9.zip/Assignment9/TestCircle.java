import acm.program.ConsoleProgram;

public class TestCircle extends ConsoleProgram {

  /*
   * YOU DO NOT NEED TO MODIFY THIS FILE. It is here to provide a test so you
   * can check if your Circle.java is written correctly.
   */

  private static final double PI = 3.14159;

  public void run() {
    Circle c1 = new Circle(10);

    println("Set c1 to be a circle with radius 10.");
    println("c1.getRadius() returns " + c1.getRadius() + ", should return "
        + (double) 10 + ".");
    println("c1.getCircumference() returns " + c1.getCircumference()
        + ", should return " + (2 * 10 * PI) + ".");
    println("c1.getArea() returns " + c1.getArea() + ", should return "
        + (PI * 10 * 10) + ".");

    Circle c2 = new Circle(5);
    Circle c3 = new Circle(10);

    println("Set c2 to be a circle with radius 5.");
    println("Set c3 to be a cirlce with radius 10.");
    println("c1.equals(c1) returns " + c1.equals(c1) + ", should return true.");
    println("c1.equals(c2) returns " + c1.equals(c2) + ", should return false.");
    println("c1.equals(c3) returns " + c1.equals(c3) + ", should return true.");
  }

}
