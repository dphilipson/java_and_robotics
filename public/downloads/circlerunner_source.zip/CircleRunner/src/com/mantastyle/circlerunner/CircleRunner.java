package com.mantastyle.circlerunner;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import acm.graphics.GLabel;
import acm.graphics.GObject;
import acm.graphics.GRect;
import acm.graphics.GRectangle;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class CircleRunner extends GraphicsProgram {

  private static final long serialVersionUID = -5953106055209647473L;

  private static final double BORDER_THICKNESS = 10.0;
  // Border extends past sides, in case window is resized.
  private static final double BORDER_EXTENSION = 1000.0;
  private static final int WINDOW_WIDTH = 1280;
  private static final int WINDOW_HEIGHT = 720;

  private static final int PAUSE_INTERVAL = 1000 / 60;
  private static final int POLLING_INTERVAL = 100;
  private static final int MESSAGE_TIME = 2000;

  private static final Color BORDER_COLOR = Color.BLACK;
  private static final String FONT = "Arial-BOLD-18";

  private static final int VICTORY_ANIMATION_NUM_BALLS = 30;
  private static final RandomRange VICTORY_ANIMATION_RADIUS_RANGE = new RandomRange(
      20.0, 75.0);
  private static final RandomRange VICTORY_ANIMATION_SPEED_RANGE = new RandomRange(
      3.0, 6.0);

  private GRectangle bounds;
  private GLabel messageLabel;
  private LevelEvent eventReceived = LevelEvent.NONE;
  private MouseState mouseState = MouseState.DISABLED;
  private PlayerBall player;
  private GoalLocation goal;

  private static enum MouseState {
    DISABLED, CLICK_TO_START, IN_GAME
  }

  public void run() {
    initialize();
    
    // Play last level, for testing
    // playLevel(Levels.list[Levels.list.length - 1], Levels.list.length - 1);

    for (int i = 0; i < Levels.list.length; i++) {
      playLevel(Levels.list[i], i + 1);
    }
    playVictoryAnimation();
  }

  /**
   * Plays though the given level, granting the player repeated attempts until
   * they succeed.
   * 
   * @param level
   *          The level to be played.
   * @param num
   *          The number of this level, for displaying
   */
  private void playLevel(Level level, int num) {
    boolean levelSucceeded = false;
    while (!levelSucceeded) {
      levelSucceeded = playSingleLife(level, num);
    }
  }

  /**
   * Plays a single attempt at a given level, starting from allowing the user to
   * click to begin and ending when the player completes the level or dies, and
   * displaying a message acknowledging this result. Returns true if the player
   * succeeded, and false if he or she failed.
   * 
   * @param level
   *          The level to be played
   * @param num
   *          The number of this level, for displaying
   * @return True if the player completed the level
   */
  private boolean playSingleLife(Level level, int num) {
    player = level.constructPlayer();
    Vector2D startPosition = level.getStartPosition();
    StartLocation start = new StartLocation(startPosition.getX(),
        startPosition.getY(), player.getRadius());
    add(start);

    Vector2D goalPosition = level.getGoalPosition();
    goal = new GoalLocation(goalPosition.getX(), goalPosition.getY(),
        level.getPlayerRadius(), level.getUnlockTime());

    waitForStartClick("Level " + num + ": " + level.getMessage());

    MovingBallManager manager = new MovingBallManager(level.constructBallList(
        player, bounds), this);
    manager.addBallsToCanvas();
    player.getOval().sendToFront();
    add(goal);
    goal.sendToBack();
    goal.startTimer();

    eventReceived = LevelEvent.NONE;
    while (eventReceived == LevelEvent.NONE) {
      eventReceived = manager.moveAll();
      if (playerIsVictorious()) {
        eventReceived = LevelEvent.LEVEL_COMPLETE;
      }
      goal.updateTimer();
      pause(PAUSE_INTERVAL);
    }
    mouseState = MouseState.DISABLED;
    if (eventReceived == LevelEvent.LEVEL_COMPLETE) {
      displayCenteredMessage("Level " + num + " complete!");
    } else if (eventReceived == LevelEvent.LEVEL_FAILED) {
      displayCenteredMessage("Level failed!");
    }
    pause(MESSAGE_TIME);
    hideCenteredMessage();
    manager.removeBallsFromCanvas();
    remove(goal);
    return eventReceived == LevelEvent.LEVEL_COMPLETE;
  }

  private void waitForStartClick(String message) {
    displayCenteredMessage(message);
    mouseState = MouseState.CLICK_TO_START;
    while (mouseState == MouseState.CLICK_TO_START) {
      pause(POLLING_INTERVAL);
    }
    hideCenteredMessage();
  }

  private boolean playerIsVictorious() {
    return goal.isActive() && !player.isOutOfBounds(goal.getBounds());
  }

  @Override
  public void mouseMoved(MouseEvent e) {
    if (mouseState == MouseState.IN_GAME) {
      player.setCenter(e.getX(), e.getY());
      if (player.isOutOfBounds(bounds)) {
        eventReceived = LevelEvent.LEVEL_FAILED;
      }
      if (playerIsVictorious()) {
        eventReceived = LevelEvent.LEVEL_COMPLETE;
      }
    }
  }

  @Override
  public void mouseDragged(MouseEvent e) {
    mouseMoved(e);
  }

  @Override
  public void mouseClicked(MouseEvent e) {
    if (mouseState == MouseState.CLICK_TO_START) {
      GObject o = getElementAt(e.getX(), e.getY());
      if (o instanceof StartLocation) {
        remove(o);
        mouseState = MouseState.IN_GAME;
      }
    }
  }

  /**
   * Plays an animation celebrating the player's victory.
   */
  private void playVictoryAnimation() {
    List<MovingBall> balls = new ArrayList<MovingBall>();
    RandomGenerator rand = RandomGenerator.getInstance();
    for (int i = 0; i < VICTORY_ANIMATION_NUM_BALLS; i++) {
      double radius = VICTORY_ANIMATION_RADIUS_RANGE.getRandom();
      double speed = VICTORY_ANIMATION_SPEED_RANGE.getRandom();
      double x = rand.nextDouble(bounds.getX() + radius,
          bounds.getX() + bounds.getWidth() - radius);
      double y = rand.nextDouble(bounds.getY() + radius,
          bounds.getY() + bounds.getHeight() - radius);
      MovingBall ball = new NonplayerBall(x, y, radius, speed,
          rand.nextColor(), bounds);
      balls.add(ball);
      add(ball.getOval());
    }
    displayCenteredMessage("You have completed all levels! Congratulations!");
    MovingBallManager manager = new MovingBallManager(balls, this);
    while (true) {
      manager.moveAll();
      pause(PAUSE_INTERVAL);
    }

  }

  private void initialize() {
    addBorder();
    bounds = new GRectangle(BORDER_THICKNESS, BORDER_THICKNESS, WINDOW_WIDTH
        - 2 * BORDER_THICKNESS, WINDOW_HEIGHT - 2 * BORDER_THICKNESS);
    messageLabel = new GLabel("");
    messageLabel.setFont(FONT);
    addMouseListeners();
    setWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    // this.setSize(WINDOW_WIDTH + WINDOW_BUFFER, WINDOW_HEIGHT
    // + TITLE_BAR_THICKNESS + WINDOW_BUFFER);
  }

  private void addBorder() {
    addBorderRectangle(0.0, 0.0, BORDER_THICKNESS, WINDOW_HEIGHT);
    addBorderRectangle(0.0, 0.0, WINDOW_WIDTH, BORDER_THICKNESS);
    addBorderRectangle(WINDOW_WIDTH - BORDER_THICKNESS, 0.0, BORDER_THICKNESS
        + BORDER_EXTENSION, WINDOW_HEIGHT + BORDER_EXTENSION);
    addBorderRectangle(0.0, WINDOW_HEIGHT - BORDER_THICKNESS, WINDOW_WIDTH
        + BORDER_EXTENSION, BORDER_THICKNESS + BORDER_EXTENSION);
  }

  private void addBorderRectangle(double x, double y, double width,
      double height) {
    GRect rect = new GRect(x, y, width, height);
    rect.setColor(BORDER_COLOR);
    rect.setFilled(true);
    add(rect);
  }

  public static void main(String[] args) {
    new CircleRunner().start(args);
  }

  private void displayCenteredMessage(String text) {
    double centerX = bounds.getX() + bounds.getWidth() / 2;
    double centerY = bounds.getY() + bounds.getHeight() / 2;

    messageLabel.setLabel(text);
    messageLabel.setLocation(centerX - messageLabel.getWidth() / 2, centerY
        + messageLabel.getHeight() / 2);
    add(messageLabel);
  }

  private void hideCenteredMessage() {
    remove(messageLabel);
  }

  /**
   * Sets the window size to the given dimensions. Used instead of setSize()
   * because the ACM libraries are a piece of shit.
   * 
   * @param width
   *          The new width
   * @param height
   *          The new height
   */
  private void setWindowSize(int width, int height) {
    setSize(width, height);
    int widthBias = width - getWidth();
    int heightBias = height - getHeight();
    setSize(width + widthBias, height + heightBias);
  }

}
