package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.graphics.GRectangle;

public class SeekerBall extends EnemyBall {

  private static final Color SEEKER_COLOR = new Color(160, 32, 120);
  
  private double speed;
  private MovingBall target; 

  public SeekerBall(double x, double y, double radius, double speed,
      MovingBall target, GRectangle bounds) {
    super(x, y, radius, speed, bounds);
    this.speed = speed;
    this.target = target;
    ball.setFillColor(SEEKER_COLOR);
  }

  @Override
  public void move() {
    Vector2D velocity = getVelocity();
    ball.move(velocity.getX(), velocity.getY());
  }

  @Override
  public Vector2D getVelocity() {
    return target.getCenter().minus(getCenter()).unit()
        .scalarMultiply(speed);
  }

  @Override
  public void setVelocity(double dx, double dy) {
    // Does nothing. The seeker ball is relentless.
  }

}
