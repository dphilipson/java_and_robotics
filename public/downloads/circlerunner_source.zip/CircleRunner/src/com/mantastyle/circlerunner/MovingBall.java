package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.graphics.GOval;
import acm.graphics.GRectangle;

public abstract class MovingBall {

  protected final GOval ball;

  public MovingBall(double x, double y, double radius, Color color) {
    GOval oval = new GOval(2 * radius, 2 * radius);
    oval.setFillColor(color);
    oval.setFilled(true);
    ball = oval;
    setCenter(x, y);
  }

  public abstract void move();

  public final boolean isOverlapping(MovingBall other) {
    return distanceTo(other) < getRadius() + other.getRadius();
  }

  public GOval getOval() {
    return ball;
  }

  /*
   * Responds to a collision, adjusting the velocity of both balls. This should
   * only be called once for each pair of colliding balls.
   */
  public final LevelEvent collide(MovingBall other) {
    Vector2D axisUnit = other.getCenter().minus(getCenter()).unit();
    Vector2D thisVelocity = getVelocity();
    Vector2D otherVelocity = other.getVelocity();
    double vThis = thisVelocity.dot(axisUnit);
    double vOther = otherVelocity.dot(axisUnit);
    double mThis = getMass();
    double mOther = other.getMass();
    double newVThis = (vThis * (mThis - mOther) + 2 * mOther * vOther)
        / (mThis + mOther);
    double newVOther = (vOther * (mOther - mThis) + 2 * mThis * vThis)
        / (mThis + mOther);
    Vector2D newThisVelocity = thisVelocity.withComponent(axisUnit, newVThis);
    Vector2D newOtherVelocity = otherVelocity
        .withComponent(axisUnit, newVOther);
    setVelocity(newThisVelocity);
    other.setVelocity(newOtherVelocity);

    LevelEvent result1 = finishCollision(other);
    LevelEvent result2 = other.finishCollision(this);
    if (result1 == LevelEvent.NONE) {
      return result2;
    }
    return result1;
  }

  public abstract Vector2D getVelocity();

  public abstract void setVelocity(double dx, double dy);

  public void setVelocity(Vector2D v) {
    setVelocity(v.getX(), v.getY());
  }

  /**
   * Called on each ball involved in a collision after adjusting their
   * velocities. This version does nothing and is intended to be overridden.
   */
  protected LevelEvent finishCollision(MovingBall other) {
    return LevelEvent.NONE;
  }

  public void setCenter(double x, double y) {
    ball.setLocation(x - getRadius(), y - getRadius());
  }

  public void setCenter(Vector2D p) {
    setCenter(p.getX(), p.getY());
  }

  private double getLeft() {
    return ball.getX();
  }

  private double getRight() {
    return ball.getX() + ball.getWidth();
  }

  private double getTop() {
    return ball.getY();
  }

  private double getBottom() {
    return ball.getY() + ball.getHeight();
  }

  protected boolean isOutOfBoundsLeft(GRectangle bounds) {
    return getLeft() < bounds.getX();
  }

  protected boolean isOutOfBoundsRight(GRectangle bounds) {
    return getRight() > bounds.getX() + bounds.getWidth();
  }

  protected boolean isOutOfBoundsTop(GRectangle bounds) {
    return getTop() < bounds.getY();
  }

  protected boolean isOutOfBoundsBottom(GRectangle bounds) {
    return getBottom() > bounds.getY() + bounds.getHeight();
  }

  public boolean isOutOfBounds(GRectangle bounds) {
    return isOutOfBoundsLeft(bounds) || isOutOfBoundsTop(bounds)
        || isOutOfBoundsRight(bounds) || isOutOfBoundsBottom(bounds);
  }

  public double getRadius() {
    return ball.getWidth() / 2;
  }

  /**
   * Changes the radius of the ball while maintaining the position of its
   * center.
   * 
   * @param r
   *          The new radius
   */
  public void setRadius(double r) {
    Vector2D oldCenter = getCenter();
    getOval().setSize(2 * r, 2 * r);
    setCenter(oldCenter.getX(), oldCenter.getY());
  }

  public final double distanceTo(MovingBall other) {
    return getCenter().minus(other.getCenter()).norm();
  }

  public Vector2D getCenter() {
    return new Vector2D(getLeft() + getRadius(), getTop() + getRadius());
  }

  public double getMass() {
    double r = getRadius();
    return r * r;
  }
}