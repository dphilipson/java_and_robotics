package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.graphics.GCompound;
import acm.graphics.GLabel;
import acm.graphics.GRect;

public class GoalLocation extends GCompound {

  private static final Color INACTIVE_COLOR = Color.GRAY;
  private static final Color ACTIVE_COLOR = Color.GREEN;
  private static final String FONT = "Arial-BOLD-14";
  private static double GOAL_BUFFER = 5.0;

  private GRect rect;
  private GLabel timeLabel;
  private int unlockTime;
  private boolean active = false;
  private long startTime = System.currentTimeMillis();

  public GoalLocation(double x, double y, double radius, int unlockTime) {
    radius += GOAL_BUFFER;
    rect = new GRect(x - radius, y - radius, 2 * radius, 2 * radius);
    rect.setColor(INACTIVE_COLOR);
    rect.setFilled(true);
    add(rect);

    timeLabel = new GLabel("");
    timeLabel.setFont(FONT);
    add(timeLabel);
    
    this.unlockTime = unlockTime;
  }

  public void startTimer() {
    startTime = System.currentTimeMillis();
    updateTimer();
  }

  public boolean isActive() {
    return active;
  }

  public void updateTimer() {
    if (active) {
      return;
    }
    long currentTime = System.currentTimeMillis();
    int remainingTime = unlockTime - (int) (currentTime - startTime);
    if (remainingTime < 0) {
      activateGoal();
    } else {
      timeLabel.setLabel(formatTime(remainingTime));
      double centerX = rect.getX() + rect.getWidth() / 2;
      double centerY = rect.getY() + rect.getHeight() / 2;
      timeLabel.setLocation(centerX - timeLabel.getWidth() / 2, centerY
          + timeLabel.getHeight() / 2);
    }
  }

  private void activateGoal() {
    active = true;
    rect.setColor(ACTIVE_COLOR);
    remove(timeLabel);
  }

  private static String formatTime(int timeInMillis) {
    int timeInTenthsOfSeconds = timeInMillis / 100;
    int seconds = timeInTenthsOfSeconds / 10;
    int tenths = timeInTenthsOfSeconds % 10;
    return (seconds + "." + tenths);
  }
}
