package com.mantastyle.circlerunner;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import acm.program.GraphicsProgram;

public class MovingBallManager {

  private static class MovingBallPair {
    public MovingBall first;
    public MovingBall second;

    public MovingBallPair(MovingBall first, MovingBall second) {
      this.first = first;
      this.second = second;
    }

    @Override
    public boolean equals(Object o) {
      if (o == null) {
        return false;
      }
      if (!(o instanceof MovingBallPair)) {
        return false;
      }
      MovingBallPair other = (MovingBallPair) o;
      return (first == other.first && second == other.second)
          || (first == other.second && second == other.first);
    }

    @Override
    public int hashCode() {
      return first.hashCode() + second.hashCode();
    }
  }

  private final List<MovingBall> balls;
  private final GraphicsProgram canvas;
  private final Set<MovingBallPair> disabledCollisions;

  public MovingBallManager(List<MovingBall> balls, GraphicsProgram canvas) {
    this.balls = balls;
    this.canvas = canvas;
    disabledCollisions = new HashSet<MovingBallPair>();
    disableInitialCollisions();
  }

  /**
   * Initially disable all collisions, to prevent balls from becoming stuck at
   * the start.
   */
  private void disableInitialCollisions() {
    int length = balls.size();
    for (int i = 0; i < length; i++) {
      for (int j = i + 1; j < length; j++) {
        MovingBall firstBall = balls.get(i);
        MovingBall secondBall = balls.get(j);
        disableCollisions(firstBall, secondBall);
      }
    }
  }

  /**
   * Adds all the balls this manager knows about to the graphical window.
   */
  public void addBallsToCanvas() {
    for (MovingBall ball : balls) {
      canvas.add(ball.getOval());
    }
  }

  /**
   * Removes all the balls this manager knows about from the graphical window.
   */
  public void removeBallsFromCanvas() {
    for (MovingBall ball : balls) {
      canvas.remove(ball.getOval());
    }
  }

  /**
   * Advances all MovingBalls by one frame, and triggers the effects of any
   * collisions that result.
   */
  public LevelEvent moveAll() {
    int numBalls = balls.size();

    for (MovingBall ball : balls) {
      ball.move();
    }

    for (int i = 0; i < numBalls; i++) {
      for (int j = i + 1; j < numBalls; j++) {
        MovingBall firstBall = balls.get(i);
        MovingBall secondBall = balls.get(j);
        if (firstBall.isOverlapping(secondBall)) {
          if (areCollisionsEnabled(firstBall, secondBall)) {
            LevelEvent e = firstBall.collide(secondBall);
            if (e != LevelEvent.NONE) {
              return e;
            }
            disableCollisions(firstBall, secondBall);
          }
        } else if (!areCollisionsEnabled(firstBall, secondBall)) {
          // Enable collisions on balls which no longer overlap.
          enableCollisions(firstBall, secondBall);
        }
      }
    }
    return LevelEvent.NONE;
  }

  public void addBall(MovingBall ball) {
    balls.add(ball);
  }

  public void removeBall(MovingBall ball) {
    balls.remove(ball);
  }

  /**
   * Disables collisions from registering between two balls until the next time
   * they no longer overlap.
   * 
   * @param ball1
   * @param ball2
   */
  private void disableCollisions(MovingBall ball1, MovingBall ball2) {
    disabledCollisions.add(new MovingBallPair(ball1, ball2));
  }

  /**
   * Re-enables collisions between two balls.
   * 
   * @param ball1
   * @param ball2
   */
  private void enableCollisions(MovingBall ball1, MovingBall ball2) {
    disabledCollisions.remove(new MovingBallPair(ball1, ball2));
  }

  private boolean areCollisionsEnabled(MovingBall ball1, MovingBall ball2) {
    return !disabledCollisions.contains(new MovingBallPair(ball1, ball2));
  }

}
