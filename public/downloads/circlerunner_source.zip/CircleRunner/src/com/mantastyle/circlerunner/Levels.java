package com.mantastyle.circlerunner;

public final class Levels {

  public static final Level[] list = {
    
      new Level.Builder().startPosition(80, 360).goalPosition(900, 360)
          .basicEnemies(4).enemyRadiusRange(50, 75).enemySpeedRange(1, 2)
          .playerRadius(40).unlockTime(6000).message("Click the box to begin")
          .build(),

      new Level.Builder().startPosition(80, 600).goalPosition(700, 200)
          .basicEnemies(8).enemyRadiusRange(40, 60).enemySpeedRange(1, 3)
          .playerRadius(30).unlockTime(10000).message("Child's Play").build(),

      new Level.Builder().message("Swing of Things").startPosition(700, 80)
          .goalPosition(60, 60).enemyRadiusRange(40, 70)
          .enemySpeedRange(2, 2.5).playerRadius(30).unlockTime(12000)
          .basicEnemies(12).build(),

      new Level.Builder().message("Mass Effect").startPosition(120, 600)
          .goalPosition(1000, 400).basicEnemies(20).enemySpeedRange(2, 2.5)
          .enemyRadiusRange(5, 50).playerRadius(20).unlockTime(12000).build(),
          
      new Level.Builder().message("Drift")
          .startPosition(1180, 620).goalPosition(100, 150).basicEnemies(120)
          .enemyRadiusRange(4, 6).enemySpeedRange(0.4, 0.6)
          .playerRadius(7).unlockTime(18000).build(),

      new Level.Builder().message("Blockade Runner").startPosition(60, 360)
          .goalPosition(1000, 300).basicEnemies(40).enemySpeedRange(1, 3)
          .enemyRadiusRange(20, 50).playerRadius(10).unlockTime(8000)
          .initialSpacing(900).build(),
 
      new Level.Builder().message("Survivalist")
          .startPosition(640, 360).goalPosition(640, 360).basicEnemies(25)
          .enemySpeedRange(2, 4).enemyRadiusRange(15, 40).playerRadius(20)
          .unlockTime(18000).initialSpacing(300).build(),
          
      new Level.Builder().message("The Seeker")
          .startPosition(90, 500).goalPosition(600, 100).playerRadius(30)
          .seekers(1).seekerRadius(70).seekerSpeed(6).unlockTime(15000).build(),
          
      new Level.Builder().message("Javert")
          .startPosition(900, 200).goalPosition(100, 600).basicEnemies(15)
          .enemySpeedRange(1, 3).enemyRadiusRange(20, 40).seekers(1)
          .seekerRadius(40).seekerSpeed(2).playerRadius(20).unlockTime(12000)
          .initialSpacing(300).build(),
          
      new Level.Builder().message("The Swarm")
          .startPosition(40, 360).goalPosition(1200, 360).basicEnemies(60)
          .enemySpeedRange(4, 6).enemyRadiusRange(4, 6).playerRadius(8)
          .unlockTime(5000).initialSpacing(1000).build(),
          
      new Level.Builder().message("Giant's Race")
          .startPosition(80, 400).goalPosition(1200, 300).basicEnemies(20)
          .enemySpeedRange(1, 3).enemyRadiusRange(20, 60).seekers(1)
          .seekerRadius(40).seekerSpeed(3).playerRadius(5).unlockTime(10000)
          .initialSpacing(300).build(),
          
      new Level.Builder().message("Gulliver")
          .startPosition(1100, 70).goalPosition(100, 200)
          .basicEnemies(30).enemySpeedRange(1, 4).enemyRadiusRange(5, 15)
          .playerRadius(45).unlockTime(12000).build(),
          
      new Level.Builder().message("The Pacifists")
          .startPosition(100, 150).goalPosition(1000, 680).basicEnemies(3)
          .enemySpeedRange(2, 2).enemyRadiusRange(40, 40).pacifists(40)
          .pacifistSpeedRange(1, 3).pacifistRadiusRange(25, 50)
          .playerRadius(30).unlockTime(10000).initialSpacing(200).build(),
          
      new Level.Builder().message("Indifferent Guardians")
          .startPosition(560, 280).goalPosition(700, 280).basicEnemies(28)
          .enemySpeedRange(1, 3).enemyRadiusRange(15, 40)
          .pacifists(6).pacifistSpeedRange(1, 3).pacifistRadiusRange(35, 55)
          .playerRadius(30).unlockTime(20000).initialSpacing(400).build(),

      new Level.Builder().message("Waking the Dragon")
          .startPosition(200, 100).goalPosition(800, 600).basicEnemies(45)
          .enemyRadiusRange(5, 5).enemySpeedRange(0.4, 0.6)
          .pacifists(2).pacifistSpeedRange(3, 3).pacifistRadiusRange(40, 40)
          .playerRadius(7).unlockTime(15000).build(),
          
      new Level.Builder().message("The Chase")
          .startPosition(850, 80).goalPosition(80, 660).basicEnemies(10)
          .enemySpeedRange(2, 3).enemyRadiusRange(20, 30)
          .pacifists(10).pacifistSpeedRange(1, 2).pacifistRadiusRange(25, 35)
          .seekers(1).seekerRadius(15).seekerSpeed(5)
          .playerRadius(15).unlockTime(12000).build(),

  };

  private Levels() {
    // Should never be called.
    throw new AssertionError("Called constructor on non-instantiatable class.");
  }

}
