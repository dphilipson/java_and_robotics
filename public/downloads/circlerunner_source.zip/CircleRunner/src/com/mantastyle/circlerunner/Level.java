package com.mantastyle.circlerunner;

import java.util.ArrayList;
import java.util.List;

import acm.graphics.GRectangle;
import acm.util.RandomGenerator;

public class Level {

  public static class Builder {

    // Default values
    private double playerRadius = 15.0;
    private double startX = 50.0;
    private double startY = 50.0;
    private double goalX = 600.0;
    private double goalY = 400.0;
    private double initialSpacing = 200.0;
    private int unlockTime = 10000;

    private int numEnemyBalls = 0;
    private double minEnemyRadius = 25.0;
    private double maxEnemyRadius = 75.0;
    private double minEnemySpeed = 1.0;
    private double maxEnemySpeed = 2.0;

    private int numSeekers = 0;
    private double seekerRadius = 30.0;
    private double seekerSpeed = 3.0;

    private int numPacifists = 0;
    private double minPacifistRadius = 25.0;
    private double maxPacifistRadius = 75.0;
    private double minPacifistSpeed = 1.0;
    private double maxPacifistSpeed = 2.0;

    private String message = "";

    public Builder playerRadius(double r) {
      playerRadius = r;
      return this;
    }

    public Builder startPosition(double x, double y) {
      startX = x;
      startY = y;
      return this;
    }

    public Builder goalPosition(double x, double y) {
      goalX = x;
      goalY = y;
      return this;
    }

    public Builder initialSpacing(double spacing) {
      initialSpacing = spacing;
      return this;
    }

    public Builder unlockTime(int milliseconds) {
      unlockTime = milliseconds;
      return this;
    }

    public Builder basicEnemies(int count) {
      numEnemyBalls = count;
      return this;
    }

    public Builder enemyRadiusRange(double min, double max) {
      minEnemyRadius = min;
      maxEnemyRadius = max;
      return this;
    }

    public Builder enemySpeedRange(double min, double max) {
      minEnemySpeed = min;
      maxEnemySpeed = max;
      return this;
    }

    public Builder seekers(int count) {
      numSeekers = count;
      return this;
    }

    public Builder seekerRadius(double radius) {
      seekerRadius = radius;
      return this;
    }

    public Builder seekerSpeed(double speed) {
      seekerSpeed = speed;
      return this;
    }

    public Builder pacifists(int count) {
      numPacifists = count;
      return this;
    }

    public Builder pacifistRadiusRange(double min, double max) {
      minPacifistRadius = min;
      maxPacifistRadius = max;
      return this;
    }

    public Builder pacifistSpeedRange(double min, double max) {
      minPacifistSpeed = min;
      maxPacifistSpeed = max;
      return this;
    }

    public Builder message(String text) {
      message = text;
      return this;
    }

    public Level build() {
      return new Level(this);
    }
  }

  private final double playerRadius;
  private final Vector2D startPosition;
  private final Vector2D goalPosition;
  private final double initialSpacing;
  private final int numEnemyBalls;
  private final RandomRange enemyRadiusRange;
  private final RandomRange enemySpeedRange;
  private final int numSeekers;
  private final double seekerRadius;
  private final double seekerSpeed;
  private final int numPacifists;
  private final RandomRange pacifistRadiusRange;
  private final RandomRange pacifistSpeedRange;
  private final int unlockTime;
  private final String message;

  private Level(Builder b) {
    playerRadius = b.playerRadius;
    startPosition = new Vector2D(b.startX, b.startY);
    goalPosition = new Vector2D(b.goalX, b.goalY);
    initialSpacing = b.initialSpacing;
    numEnemyBalls = b.numEnemyBalls;
    enemyRadiusRange = new RandomRange(b.minEnemyRadius, b.maxEnemyRadius);
    enemySpeedRange = new RandomRange(b.minEnemySpeed, b.maxEnemySpeed);
    numSeekers = b.numSeekers;
    seekerRadius = b.seekerRadius;
    seekerSpeed = b.seekerSpeed;
    numPacifists = b.numPacifists;
    pacifistRadiusRange = new RandomRange(b.minPacifistRadius,
        b.maxPacifistRadius);
    pacifistSpeedRange = new RandomRange(b.minPacifistSpeed, b.maxPacifistSpeed);
    unlockTime = b.unlockTime;
    message = b.message;
  }

  public Vector2D getStartPosition() {
    return startPosition;
  }

  public Vector2D getGoalPosition() {
    return goalPosition;
  }

  public double getPlayerRadius() {
    return playerRadius;
  }

  public int getUnlockTime() {
    return unlockTime;
  }

  public String getMessage() {
    return message;
  }

  public PlayerBall constructPlayer() {
    return new PlayerBall(startPosition.getX(), startPosition.getY(),
        playerRadius);
  }

  public List<MovingBall> constructBallList(PlayerBall player, GRectangle bounds) {
    List<MovingBall> balls = new ArrayList<MovingBall>();

    // Add the player ball.
    balls.add(player);

    // Add the enemy balls.
    for (int i = 0; i < numEnemyBalls; i++) {
      double radius = enemyRadiusRange.getRandom();
      double speed = enemySpeedRange.getRandom();
      Vector2D location = generateLocation(radius, bounds);
      EnemyBall enemy = new EnemyBall(location.getX(), location.getY(), radius,
          speed, bounds);
      balls.add(enemy);
    }

    /*
     * Note that pacifists are added before seekers, so that seekers are drawn
     * on top of pacifists on the canvas.
     */

    // Add pacifists.
    for (int i = 0; i < numPacifists; i++) {
      double radius = pacifistRadiusRange.getRandom();
      double speed = pacifistSpeedRange.getRandom();
      Vector2D location = generateLocation(radius, bounds);
      PacifistBall pacifist = new PacifistBall(location.getX(), location.getY(), radius, speed, bounds);
      balls.add(pacifist);
    }

    // Add seeker balls
    for (int i = 0; i < numSeekers; i++) {
      Vector2D location = generateLocation(seekerRadius, bounds);
      SeekerBall seeker = new SeekerBall(location.getX(), location.getY(),
          seekerRadius, seekerSpeed, player, bounds);
      balls.add(seeker);
    }

    return balls;
  }

  /**
   * Selects a random location for the center of a ball, under the conditions
   * that the ball will fit within the bounds and that it is at least a given
   * distance away from the player's start location.
   * 
   * @param radius
   *          The radius of the ball for which a location is being generated
   * @param initialSpacing
   *          The minimum distance from the player ball
   * @return A location as a Vector2D
   */
  private Vector2D generateLocation(double radius, GRectangle bounds) {
    RandomGenerator rand = RandomGenerator.getInstance();
    while (true) {
      double centerX = rand.nextDouble(bounds.getX() + radius, bounds.getX()
          + bounds.getWidth() - radius);
      double centerY = rand.nextDouble(bounds.getY() + radius, bounds.getY()
          + bounds.getHeight() - radius);
      Vector2D location = new Vector2D(centerX, centerY);
      if (location.distanceTo(getStartPosition()) > initialSpacing) {
        return location;
      }
    }
  }

}
