package com.mantastyle.circlerunner;

import acm.graphics.GRectangle;

public class EnemyBall extends NonplayerBall {

  public EnemyBall(double x, double y, double radius, double speed,
      GRectangle bounds) {
    super(x, y, radius, speed, ColorUtils.randomRed(), bounds);
  }

  @Override
  protected LevelEvent finishCollision(MovingBall other) {
    if (other instanceof PlayerBall) {
      return LevelEvent.LEVEL_FAILED;
    }
    return LevelEvent.NONE;
  }

}
