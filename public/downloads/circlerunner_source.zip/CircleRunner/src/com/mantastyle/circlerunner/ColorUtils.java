package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.util.RandomGenerator;

public final class ColorUtils {
  
  private static final RandomGenerator rand = RandomGenerator.getInstance();

  /**
   * Returns a random shade of red.
   * @return A reddish Color
   */
  static Color randomRed() {
    return new Color(rand.nextInt(128, 255), 0, 0);
  }
  
  static Color randomLightBlue() {
    int hue = rand.nextInt(128, 196);
    return new Color(hue, hue, 255);
  }
  
  private ColorUtils() {
    // Should never be called.
    throw new AssertionError("Called constructor on non-instantiatable class.");
  }
  
}
