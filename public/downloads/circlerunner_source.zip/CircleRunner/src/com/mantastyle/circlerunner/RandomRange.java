package com.mantastyle.circlerunner;

import acm.util.RandomGenerator;

public class RandomRange {

  private final double min;
  private final double max;

  private static final RandomGenerator rand = RandomGenerator.getInstance();

  public RandomRange(double min, double max) {
    if (min > max) {
      throw new AssertionError("Min value is greater than max in RandomRange.");
    }
    this.min = min;
    this.max = max;
  }

  public double getRandom() {
    if (min == max) {
      return min;
    } else {
      return rand.nextDouble(min, max);
    }
  }
  
  public double getMin() {
    return min;
  }
  
  public double getMax() {
    return max;
  }

}
