package com.mantastyle.circlerunner;

public class Vector2D {

  private final double x;
  private final double y;
  
  public static final Vector2D ZERO = new Vector2D(0.0, 0.0);

  public Vector2D(double x, double y) {
    this.x = x;
    this.y = y;
  }

  public double getX() {
    return x;
  }

  public double getY() {
    return y;
  }

  public Vector2D plus(Vector2D other) {
    return new Vector2D(x + other.x, y + other.y);
  }

  public Vector2D minus(Vector2D other) {
    return new Vector2D(x - other.x, y - other.y);
  }

  public Vector2D negative() {
    return new Vector2D(-x, -y);
  }

  public Vector2D perp() {
    return new Vector2D(-y, x);
  }

  public double dot(Vector2D other) {
    return x * other.x + y * other.y;
  }

  public double norm() {
    return Math.sqrt(this.dot(this));
  }
  
  public double distanceTo(Vector2D other) {
    return this.minus(other).norm();
  }

  public Vector2D unit() {
    double norm = norm();
    return new Vector2D(x / norm, y / norm);
  }

  public Vector2D scalarMultiply(double c) {
    return new Vector2D(c * x, c * y);
  }

  public Vector2D project(Vector2D direction) {
    Vector2D unitDirection = direction.unit();
    return unitDirection.scalarMultiply(this.dot(unitDirection));
  }

  /**
   * Returns a new Vector2D representing this one, but with the component in a
   * given direction changed to the selected value. Leaves the other
   * (perpendicular) component unchanged.
   * 
   * @param direction
   *          The direction of the component to be changed
   * @param magnitude
   *          The new magnitude along that component
   * @return A new Vector2D object
   */
  public Vector2D withComponent(Vector2D direction, double magnitude) {
    Vector2D perpComponent = this.minus(this.project(direction));
    return perpComponent.plus(direction.unit().scalarMultiply(magnitude));
  }
}
