package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.graphics.GRect;

public class StartLocation extends GRect {
  
  private static final Color START_LOCATION_COLOR = Color.GREEN;
  
  public StartLocation(double x, double y, double radius) {
    super(x - radius, y - radius, 2 * radius, 2 * radius);
    setColor(START_LOCATION_COLOR);
    setFilled(true);
  }
}
