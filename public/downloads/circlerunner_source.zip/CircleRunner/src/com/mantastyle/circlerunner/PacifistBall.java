package com.mantastyle.circlerunner;

import acm.graphics.GRectangle;

public class PacifistBall extends NonplayerBall {

  public PacifistBall(double x, double y, double radius, double speed,
      GRectangle bounds) {
    super(x, y, radius, speed, ColorUtils.randomLightBlue(), bounds);
  }
  
}
