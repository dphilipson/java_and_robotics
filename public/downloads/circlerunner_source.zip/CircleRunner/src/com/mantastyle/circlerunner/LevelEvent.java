package com.mantastyle.circlerunner;

public enum LevelEvent {
  NONE, LEVEL_COMPLETE, LEVEL_FAILED
}
