package com.mantastyle.circlerunner;

import java.awt.Color;

public class PlayerBall extends MovingBall {

  private static final Color PLAYER_COLOR = Color.BLUE;
  
  private double measuredDx;
  private double measuredDy;
  private double lastX;
  private double lastY;

  public PlayerBall(double x, double y, double radius) {
    super(x, y, radius, PLAYER_COLOR);
    lastX = x;
    lastY = y;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.mantastyle.circlerunner.MovingBall#move()
   * 
   * Despite the name, does not move the player (movement is controlled by the
   * mouse). Instead, updates the stored velocity fields based on how much the
   * player's position has changed since the last move() call.
   */
  @Override
  public void move() {
    measuredDx = ball.getX() - lastX;
    measuredDy = ball.getY() - lastY;
    lastX = ball.getX();
    lastY = ball.getY();
  }

  @Override
  public Vector2D getVelocity() {
    // The player ball's velocity is measured from mouse movements.
    return new Vector2D(measuredDx, measuredDy);
  }

  @Override
  public void setVelocity(double dx, double dy) {
    // Does nothing. The ball's movement is controlled by the mouse.
  }

}
