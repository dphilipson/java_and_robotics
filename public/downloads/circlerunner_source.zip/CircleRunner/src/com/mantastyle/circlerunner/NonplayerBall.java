package com.mantastyle.circlerunner;

import java.awt.Color;

import acm.graphics.GRectangle;
import acm.util.RandomGenerator;

public class NonplayerBall extends MovingBall {

  protected double dx;
  protected double dy;
  protected GRectangle bounds;

  public NonplayerBall(double x, double y, double radius, double speed,
      Color color, GRectangle bounds) {
    super(x, y, radius, color);

    RandomGenerator rand = RandomGenerator.getInstance();
    double angle = rand.nextDouble(0, 2 * Math.PI);
    dx = speed * Math.cos(angle);
    dy = speed * Math.sin(angle);
    this.bounds = bounds;
  }

  @Override
  public void move() {
    if (isOutOfBoundsLeft(bounds) && dx < 0) {
      dx = -dx;
    } else if (isOutOfBoundsRight(bounds) && dx > 0) {
      dx = -dx;
    }
    if (isOutOfBoundsTop(bounds) && dy < 0) {
      dy = -dy;
    } else if (isOutOfBoundsBottom(bounds) && dy > 0) {
      dy = -dy;
    }
    ball.move(dx, dy);
  }

  @Override
  public Vector2D getVelocity() {
    return new Vector2D(dx, dy);
  }

  @Override
  public void setVelocity(double dx, double dy) {
    this.dx = dx;
    this.dy = dy;
  }

}
